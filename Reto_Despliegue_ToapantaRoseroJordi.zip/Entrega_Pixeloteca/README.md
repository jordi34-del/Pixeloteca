# Pixeloteca

Proyecto académico para el módulo **Diseño de Interfaces Web**. Sitio web temático sobre videojuegos con cuatro páginas, diseño adaptable (responsive) y gestión de registros mediante AJAX, Java Servlet y MariaDB.

## 1. Tecnologías utilizadas

- HTML5
- CSS3
- JavaScript y Fetch API
- Java 21
- Jakarta Servlet 6.0
- Apache Tomcat 10.1
- Apache Maven 3.8.7
- MariaDB 10.11
- JDBC
- Gson

## 2. Estructura del proyecto

- `src/main/webapp`: páginas HTML, hojas de estilos CSS y archivos JavaScript.
- `src/main/java`: servlet y clases Java para la conexión con la base de datos.
- `sql/pixeloteca.sql`: script SQL de creación de la base de datos y su tabla.
- `documentacion`: documentación del proyecto y wireframes.
- `target/pixeloteca.war`: archivo WAR generado mediante Maven.
- `pom.xml`: configuración y dependencias del proyecto.
- `README.md`: instrucciones e información general del proyecto.

## 3. Requisitos previos

Para compilar y ejecutar el proyecto se necesitan:

- Java JDK 21.
- Apache Maven 3.8.7 o compatible.
- Apache Tomcat 10.1.
- MariaDB 10.11 o compatible.
- Navegador web actualizado.

## 4. Crear la base de datos

La aplicación utiliza MariaDB como sistema gestor de bases de datos.

Para preparar la base de datos:

1. Iniciar el servicio MariaDB.
2. Abrir la consola de MariaDB.
3. Ejecutar el contenido del archivo `sql/pixeloteca.sql`.
4. Comprobar que se ha creado la base de datos `pixeloteca`.
5. Verificar que existe la tabla `videojuegos`.

La tabla almacena los siguientes campos:

- `id`
- `titulo`
- `genero`
- `plataforma`
- `anio`
- `descripcion`
- `fecha_alta`

La base de datos contiene registros ficticios utilizados para comprobar el funcionamiento de la aplicación.

## 5. Configurar la conexión a MariaDB

La aplicación utiliza variables de entorno para configurar la conexión con la base de datos.

En el entorno de despliegue, estas variables se configuran en el archivo:

`/opt/tomcat/bin/setenv.sh`

La conexión utiliza los siguientes datos:

- Base de datos: `pixeloteca`.
- Servidor: `127.0.0.1`.
- Puerto: `3306`.
- Usuario de aplicación: `pixeloteca_app`.

La contraseña se configura mediante una variable de entorno y no se incluye en este documento.

El usuario de aplicación dispone de permisos específicos sobre la base de datos, evitando utilizar el usuario administrador para las operaciones habituales de la aplicación.

**Importante:** no se deben publicar contraseñas reales ni credenciales de acceso en el repositorio.

## 6. Compilar el proyecto

Desde la carpeta principal del proyecto, donde se encuentra el archivo `pom.xml`, ejecutar:

```bash
mvn clean package
```

Si la compilación termina correctamente, Maven genera el archivo:

`target/pixeloteca.war`

Este archivo WAR contiene la aplicación y sus dependencias necesarias para el despliegue.

## 7. Desplegar en Apache Tomcat

La aplicación se despliega en Apache Tomcat 10.1 instalado en:

`/opt/tomcat`

Se ha configurado un Host virtual independiente para Pixeloteca, utilizando el nombre:

`pixeloteca.local`

El Host virtual utiliza un directorio de aplicaciones independiente del directorio `webapps` predeterminado:

`/opt/tomcat/pixeloteca`

El archivo de despliegue se denomina:

`ROOT.war`

Para acceder a la aplicación desde otro equipo de la red es necesario configurar la resolución del nombre `pixeloteca.local` hacia la dirección IP de la máquina virtual.

La dirección IP utilizada durante las pruebas fue:

`10.10.0.221`

En el archivo hosts del equipo cliente se añadió la siguiente entrada:

```text
10.10.0.221 pixeloteca.local www.pixeloteca.local
```

Una vez iniciados Tomcat y MariaDB, se puede acceder a la aplicación mediante:

`http://pixeloteca.local:8080`

La aplicación dispone de cuatro páginas principales:

- Inicio.
- Catálogo.
- Descubre.
- Gestión.

## 8. Rutas de la API

La aplicación dispone de un servicio HTTP que permite consultar e insertar videojuegos.

La ruta de la API es:

`/api/videojuegos`

### Consulta de registros (GET)

```text
GET /api/videojuegos
```

Devuelve un array JSON con los videojuegos registrados en la base de datos.

### Inserción de registros (POST)

```text
POST /api/videojuegos
```

Recibe los datos de un videojuego en formato JSON, valida la información y guarda el registro en MariaDB.

Ejemplo de cuerpo de una petición POST:

```json
{
  "titulo": "Aventura de prueba",
  "genero": "Aventura",
  "plataforma": "PC",
  "anio": 2024,
  "descripcion": "Un juego ficticio para probar el formulario."
}
```

Respuestas HTTP previstas:

- `201`: registro creado correctamente.
- `400`: datos incorrectos o validación fallida.
- `500`: error interno del servidor.

## 9. Funcionamiento de la página Gestión

La página Gestión permite registrar nuevos videojuegos mediante un formulario.

La comunicación con el servidor se realiza mediante Fetch API y peticiones AJAX, sin necesidad de recargar la página para realizar las operaciones habituales.

La tabla de videojuegos obtiene los registros desde MariaDB a través del servicio Java.

También se muestran mensajes de carga, confirmación y error para informar al usuario sobre el resultado de las operaciones.

La dirección de la API se utiliza de forma relativa desde la aplicación, evitando depender de una dirección localhost del equipo cliente.

## 10. Pruebas

Durante el despliegue se realizaron comprobaciones del funcionamiento de la aplicación y de los servicios del servidor.

Entre las pruebas realizadas se encuentran:

- Acceso remoto a Pixeloteca desde otro equipo.
- Navegación por las cuatro páginas principales.
- Consulta de videojuegos almacenados en MariaDB.
- Inserción de nuevos videojuegos.
- Comprobación de la persistencia de los registros.
- Validación de campos obligatorios del formulario.
- Reinicio de Tomcat y comprobación posterior de la aplicación.
- Detención y recuperación del servicio MariaDB.
- Comprobación de que el servidor original de Tomcat continúa funcionando.

Las evidencias disponibles se incluyen junto con la documentación de entrega.

## 11. Limitaciones del proyecto

El proyecto implementa las operaciones de consulta e inserción de videojuegos.

No incluye funciones de edición ni eliminación de registros desde la interfaz de usuario.

El catálogo inicial contiene tarjetas de presentación de videojuegos, mientras que los registros almacenados en la base de datos se consultan desde la página Gestión.

La tipografía puede descargarse desde Google Fonts. Si no hay conexión a Internet, se utilizan fuentes alternativas del sistema.

## 12. Autoría

Proyecto académico desarrollado para el módulo de Diseño de Interfaces Web.

