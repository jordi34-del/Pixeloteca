package es.pixeloteca.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class Conexion {
    private Conexion() {}

    public static Connection obtenerConexion() throws SQLException {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("No se pudo cargar el controlador MySQL JDBC", e);
        }

        String url = System.getenv().getOrDefault(
            "PIXELoteca_DB_URL",
            "jdbc:mysql://127.0.0.1:3307/pixeloteca?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true"
        );
        String usuario = System.getenv().getOrDefault("PIXELoteca_DB_USER", "root");
        String clave = System.getenv().getOrDefault("PIXELoteca_DB_PASSWORD", "");
        return DriverManager.getConnection(url, usuario, clave);
    }
}
