package es.pixeloteca.api;

import com.google.gson.Gson;
import es.pixeloteca.db.Conexion;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.ServletException;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet("/api/videojuegos")
public class VideojuegoServlet extends HttpServlet {
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        response.setContentType("application/json;charset=UTF-8");
        List<Map<String, Object>> juegos = new ArrayList<>();
        String sql = "SELECT id, titulo, genero, plataforma, anio, descripcion FROM videojuegos ORDER BY id DESC";
        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Map<String, Object> juego = new LinkedHashMap<>();
                juego.put("id", rs.getInt("id"));
                juego.put("titulo", rs.getString("titulo"));
                juego.put("genero", rs.getString("genero"));
                juego.put("plataforma", rs.getString("plataforma"));
                juego.put("anio", rs.getInt("anio"));
                juego.put("descripcion", rs.getString("descripcion"));
                juegos.add(juego);
            }
            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().write(gson.toJson(juegos));
        } catch (SQLException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"error\":\"No se pudieron consultar los videojuegos. Comprueba la base de datos.\"}");
            getServletContext().log("Error consultando videojuegos", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");
        Map<?, ?> datos;
        try {
            datos = gson.fromJson(request.getReader(), Map.class);
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"error\":\"El cuerpo JSON no es válido.\"}");
            return;
        }

        String titulo = texto(datos, "titulo");
        String genero = texto(datos, "genero");
        String plataforma = texto(datos, "plataforma");
        String descripcion = texto(datos, "descripcion");
        Integer anio = entero(datos.get("anio"));

        if (titulo == null || titulo.length() < 2 || titulo.length() > 100 ||
            genero == null || genero.length() > 50 ||
            plataforma == null || plataforma.length() > 60 ||
            anio == null || anio < 1970 || anio > 2100 ||
            descripcion == null || descripcion.length() > 500) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"error\":\"Revisa los campos: todos son obligatorios y deben tener un formato válido.\"}");
            return;
        }

        String sql = "INSERT INTO videojuegos (titulo, genero, plataforma, anio, descripcion) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, titulo);
            ps.setString(2, genero);
            ps.setString(3, plataforma);
            ps.setInt(4, anio);
            ps.setString(5, descripcion);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                int id = keys.next() ? keys.getInt(1) : 0;
                response.setStatus(HttpServletResponse.SC_CREATED);
                response.getWriter().write(gson.toJson(Map.of("mensaje", "Videojuego guardado correctamente.", "id", id)));
            }
        } catch (SQLException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"error\":\"No se pudo guardar el videojuego. Comprueba la conexión con la base de datos.\"}");
            getServletContext().log("Error insertando videojuego", e);
        }
    }

    private String texto(Map<?, ?> datos, String campo) {
        Object valor = datos == null ? null : datos.get(campo);
        if (valor == null) return null;
        String resultado = valor.toString().trim();
        return resultado.isEmpty() ? null : resultado;
    }

    private Integer entero(Object valor) {
        if (valor == null) return null;
        try { return (int) Double.parseDouble(valor.toString()); }
        catch (NumberFormatException e) { return null; }
    }
}
