const API_URL = 'api/videojuegos';

const form = document.querySelector('#game-form');
const tableBody = document.querySelector('#games-body');
const tableStatus = document.querySelector('#table-status');
const formMessage = document.querySelector('#form-message');
const submitButton = document.querySelector('#submit-button');
const reloadButton = document.querySelector('#reload-button');

function mostrarMensaje(elemento, texto, tipo = '') {
    elemento.textContent = texto;
    elemento.className = `form-message ${tipo}`.trim();
}

function crearCelda(valor) {
    const celda = document.createElement('td');
    celda.textContent = valor ?? '';
    return celda;
}

async function cargarVideojuegos() {
    if (!tableBody) return;
    mostrarMensaje(tableStatus, 'Cargando registros...');
    tableBody.replaceChildren();

    try {
        const respuesta = await fetch(API_URL);
        if (!respuesta.ok) throw new Error('El servidor no ha podido consultar los registros.');
        const juegos = await respuesta.json();

        if (juegos.length === 0) {
            mostrarMensaje(tableStatus, 'Todavía no hay videojuegos registrados.');
            return;
        }

        juegos.forEach(juego => {
            const fila = document.createElement('tr');
            fila.append(
                crearCelda(juego.titulo),
                crearCelda(juego.genero),
                crearCelda(juego.plataforma),
                crearCelda(juego.anio),
                crearCelda(juego.descripcion)
            );
            tableBody.appendChild(fila);
        });
        mostrarMensaje(tableStatus, `Se han cargado ${juegos.length} videojuego(s).`, 'success');
    } catch (error) {
        mostrarMensaje(tableStatus, `${error.message} Comprueba que Java y MySQL estén iniciados.`, 'error');
    }
}

if (form) {
    form.addEventListener('submit', async (evento) => {
        evento.preventDefault();
        if (!form.reportValidity()) return;

        const datos = Object.fromEntries(new FormData(form).entries());
        datos.anio = Number(datos.anio);

        submitButton.disabled = true;
        submitButton.textContent = 'Guardando...';
        mostrarMensaje(formMessage, 'Enviando información...');

        try {
            const respuesta = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(datos)
            });
            const resultado = await respuesta.json();
            if (!respuesta.ok) throw new Error(resultado.error || 'No se pudo guardar el registro.');

            mostrarMensaje(formMessage, resultado.mensaje, 'success');
            form.reset();
            await cargarVideojuegos();
        } catch (error) {
            mostrarMensaje(formMessage, error.message, 'error');
        } finally {
            submitButton.disabled = false;
            submitButton.textContent = 'Guardar videojuego';
        }
    });

    reloadButton.addEventListener('click', cargarVideojuegos);
    cargarVideojuegos();
}
