CREATE DATABASE IF NOT EXISTS pixeloteca
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pixeloteca;

CREATE TABLE IF NOT EXISTS videojuegos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(100) NOT NULL,
  genero VARCHAR(50) NOT NULL,
  plataforma VARCHAR(60) NOT NULL,
  anio SMALLINT NOT NULL,
  descripcion VARCHAR(500) NOT NULL,
  fecha_alta TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Datos ficticios para comprobar la consulta inicial.
INSERT INTO videojuegos (titulo, genero, plataforma, anio, descripcion)
SELECT 'Prueba de Pixeloteca', 'Aventura', 'PC', 2024, 'Registro de ejemplo para comprobar la tabla.'
WHERE NOT EXISTS (SELECT 1 FROM videojuegos WHERE titulo = 'Prueba de Pixeloteca');
