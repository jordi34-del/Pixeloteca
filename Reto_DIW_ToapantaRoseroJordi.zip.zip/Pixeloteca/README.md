\# Pixeloteca



Proyecto académico para el módulo \*\*Diseño de Interfaces Web\*\*. Sitio temático sobre videojuegos con cuatro páginas, diseño adaptable (responsive) y gestión de registros mediante AJAX, Java Servlet y MySQL.



\## 1. Tecnologías utilizadas



\- HTML5

\- CSS3

\- JavaScript y Fetch API

\- Java 17

\- Jakarta Servlet 6.0

\- Apache Tomcat 10.1

\- Maven

\- MySQL 8



\## 2. Estructura del proyecto



\- `src/main/webapp`: páginas HTML, hojas de estilos CSS y archivos JavaScript.

\- `src/main/java`: servlet y clases de conexión JDBC.

\- `sql/pixeloteca.sql`: script de creación de la base de datos y su tabla.

\- `documentacion`: documentación DEF y wireframes.

\- `evidencias`: capturas de pantalla de las pruebas realizadas.

\- `target/pixeloteca.war`: archivo WAR generado mediante Maven.



\## 3. Requisitos previos



Para ejecutar el proyecto se necesitan:



\- Java JDK 17.

\- Apache Maven.

\- MySQL 8.

\- Apache Tomcat 10.1.

\- Navegador web actualizado.



\## 4. Crear la base de datos



1\. Abrir MySQL Workbench o la consola de MySQL.

2\. Ejecutar el contenido del archivo `sql/pixeloteca.sql`.

3\. Comprobar que se ha creado la base de datos `pixeloteca`.

4\. Verificar que existe la tabla `videojuegos`.



La tabla almacena los siguientes campos:



\- `id`

\- `titulo`

\- `genero`

\- `plataforma`

\- `anio`

\- `descripcion`

\- `fecha\_alta`



\## 5. Configurar la conexión a MySQL



La aplicación utiliza variables de entorno para configurar la conexión a la base de datos:



\- `PIXELoteca\_DB\_URL`

\- `PIXELoteca\_DB\_USER`

\- `PIXELoteca\_DB\_PASSWORD`



Configuración utilizada en el entorno de desarrollo:



\- URL: `jdbc:mysql://127.0.0.1:3307/pixeloteca?useSSL=false\&serverTimezone=UTC\&allowPublicKeyRetrieval=true`

\- Usuario: `pixeloteca\_app`

\- Contraseña: la configurada para el usuario de la aplicación.



Es necesario configurar estas variables antes de iniciar Tomcat. No se deben publicar contraseñas reales en el repositorio ni en la documentación.



\## 6. Compilar el proyecto



Desde la carpeta principal del proyecto, donde se encuentra el archivo `pom.xml`, ejecutar:



```bash

mvn clean package

```



Si la compilación termina correctamente, Maven genera el archivo:



`target/pixeloteca.war`



\## 7. Desplegar en Apache Tomcat



1\. Copiar `target/pixeloteca.war` a la carpeta `webapps` de Apache Tomcat 10.1.

2\. Comprobar que MySQL está iniciado.

3\. Iniciar Apache Tomcat.

4\. Abrir el navegador y acceder a:



`http://localhost:8080/pixeloteca/`



La aplicación dispone de cuatro páginas principales:



\- Inicio.

\- Catálogo.

\- Descubre.

\- Gestión.



\## 8. Rutas de la API



La aplicación dispone de un servicio HTTP que permite consultar e insertar videojuegos.



\*\*Consulta de registros (GET):\*\*



`/pixeloteca/api/videojuegos`



Devuelve un array JSON con los videojuegos registrados en la base de datos.



\*\*Inserción de registros (POST):\*\*



`/pixeloteca/api/videojuegos`



Recibe los datos de un videojuego en formato JSON, valida la información y guarda el registro en MySQL.



Ejemplo de cuerpo de una petición POST:



```json

{

&#x20; "titulo": "Aventura de prueba",

&#x20; "genero": "Aventura",

&#x20; "plataforma": "PC",

&#x20; "anio": 2024,

&#x20; "descripcion": "Un juego ficticio para probar el formulario."

}

```



Respuestas HTTP previstas:



\- `201`: registro creado correctamente.

\- `400`: datos incorrectos o validación fallida.

\- `500`: error interno del servidor.



\## 9. Funcionamiento de la página Gestión



La página Gestión permite registrar nuevos videojuegos mediante un formulario.



La comunicación con el servidor se realiza mediante Fetch API y peticiones AJAX, sin necesidad de recargar la página.



La tabla de videojuegos obtiene los registros desde la base de datos y se actualiza después de insertar un nuevo registro.



También se muestran mensajes de carga, confirmación y error.



\## 10. Pruebas



Las pruebas del proyecto se documentan en el apartado 12 del documento DEF.



Se incluyen comprobaciones de:



\- Consulta de videojuegos registrados.

\- Inserción de videojuegos sin recargar la página.

\- Persistencia de los datos.

\- Validación de campos obligatorios.

\- Diseño adaptable.

\- Carga y actualización dinámica de la tabla.

\- Navegación entre páginas.

\- Navegación mediante teclado.

\- Validación HTML mediante W3C.

\- Análisis con Lighthouse.



Las evidencias gráficas se guardan en la carpeta `evidencias`.



\## 11. Limitaciones del proyecto



El proyecto implementa las operaciones de consulta e inserción de videojuegos.



No incluye funciones de edición ni eliminación de registros.



El catálogo inicial contiene tarjetas de presentación de videojuegos, mientras que los registros almacenados en la base de datos se consultan desde la página Gestión.



La tipografía puede descargarse desde Google Fonts. Si no hay conexión a Internet, se utilizan fuentes alternativas del sistema.



\## 12. Autoría



Proyecto académico desarrollado para el módulo de Diseño de Interfaces Web.

