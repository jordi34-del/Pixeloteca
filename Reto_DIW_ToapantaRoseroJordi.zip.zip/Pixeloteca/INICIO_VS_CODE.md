# Primeros pasos (VS Code)

1. Abre esta carpeta en Visual Studio Code.
2. Instala la extensión **Extension Pack for Java** (Microsoft) si quieres editar y ejecutar Java desde VS Code.
3. Instala Maven y Apache Tomcat 10.1 si todavía no están instalados.
4. Ejecuta el script `sql/pixeloteca.sql` en MySQL.
5. Revisa las credenciales de MySQL en `Conexion.java` o configura las variables de entorno descritas en README.
6. Abre la terminal integrada de VS Code en la carpeta del proyecto y ejecuta `mvn clean package`.
7. Despliega `target/pixeloteca.war` en Tomcat 10.1.
8. Abre `http://localhost:8080/pixeloteca/`.

Importante: el proyecto necesita que Tomcat y MySQL estén arrancados. Abrir el HTML directamente con Live Server no ejecuta el servlet Java; para probar AJAX contra la base de datos, entra por la URL de Tomcat.
