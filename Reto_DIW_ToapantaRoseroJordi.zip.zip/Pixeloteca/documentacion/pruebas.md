# Plan de pruebas y aceptación

Completa la columna de resultado después de ejecutar cada prueba. Añade capturas propias en `evidencias/`.

| Prueba | Resultado esperado | Resultado real |
|---|---|---|
| Navegar por las cuatro páginas | Todos los enlaces funcionan | Pendiente |
| Navegar con teclado | Enlaces, campos y botones accesibles; foco visible | Pendiente |
| Enviar campos obligatorios vacíos | El navegador impide el envío | Pendiente |
| Enviar datos inválidos directamente a Java | El servicio responde HTTP 400 | Pendiente |
| Enviar un registro válido | Se inserta y aparece en la tabla sin recargar | Pendiente |
| Recargar la página tras insertar | El registro sigue apareciendo | Pendiente |
| Consultar una tabla vacía | Se muestra un mensaje de estado vacío | Pendiente |
| Detener el servicio o la base de datos | La interfaz informa del error | Pendiente |
| Revisar en móvil, tableta y escritorio | El diseño se adapta y no hay desbordamiento global | Pendiente |
| Validar HTML y revisar Lighthouse | Se anotan problemas y correcciones | Pendiente |

## Evidencias
Añade aquí el nombre de cada captura y qué prueba demuestra. No inventes resultados ni puntuaciones.
